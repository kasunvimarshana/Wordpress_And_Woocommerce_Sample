<?php
/*
Plugin Name:  Angular Plugin
Description:  Our awesome plugin
Version:      1.0.0
Author:       Lynda Author
License:      GPL3
License URI:  https://www.gnu.org/licenses/gpl-3.0.html
Text Domain:  angular-plugin
Domain Path:  /languages
*/